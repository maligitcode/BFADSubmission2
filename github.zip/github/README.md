# BFADSubmission2
Belajar Fundemental Android Developer Submision 2 Dicoding
